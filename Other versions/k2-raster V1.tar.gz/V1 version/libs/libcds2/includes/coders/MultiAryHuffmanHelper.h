//
// Created by alberto on 4/21/15.
//

#ifndef ALL_MULTIARYHUFFMANHELPER_H
#define ALL_MULTIARYHUFFMANHELPER_H


class MultiAryHuffmanHelper {


};


#endif //ALL_MULTIARYHUFFMANHELPER_H
