#!/bin/sh

echo "Removing folders..."
rm -r build

echo "DONE!!!"