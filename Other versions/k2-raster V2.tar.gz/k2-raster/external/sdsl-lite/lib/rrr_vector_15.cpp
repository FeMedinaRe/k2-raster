#include "sdsl/rrr_vector_15.hpp"

//! Namespace for the succinct data structure library
namespace sdsl
{
// initialize the inner class
binomial15::impl binomial15::iii;

} // end namespace
