Implementation of the Hu-Tucker algorithm. 
